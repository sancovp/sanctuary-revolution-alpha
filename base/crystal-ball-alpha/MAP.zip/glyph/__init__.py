"""introduction_to_cs — the MAP attention programming shell."""
