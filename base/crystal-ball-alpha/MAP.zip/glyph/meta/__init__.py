"""Meta layer — MAP interpreting Glyph.

meta_interp.py: Python-side meta-interpreter with hooks for introspection
meta_circular.map: The evaluator written IN MAP itself
bootstrap.py: Loads meta_circular.map into the base interpreter
"""
