CRITICAL: You must start reading this repository by reading `youknow()` in compiler.py line 226\!
