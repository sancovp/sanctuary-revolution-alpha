# Instantiates Semantics

## INSTANTIATES = GENERATIVE

`X instantiates Y` means **X PRODUCES Y-things**, not "X is an instance of Y".

From `hyperedge.py` line 226:
> "If X instantiates Y, and Y is_a Z, then X might produce Z-things"

## Examples

- `SkillSpec instantiates SkillPackage` = SkillSpec PRODUCES SkillPackages
- `Factory instantiates Product` = Factory PRODUCES Products
- `Template instantiates Document` = Template PRODUCES Documents

## Y-Layer Guard (PENDING)

**X cannot instantiate something higher in Reality than itself.**

If X is at Y4 (Instance), it cannot instantiate something at Y3 (Category) or higher.

This guard needs to be implemented in:
1. `hyperedge.py` HyperedgeValidator
2. `uarl_v3.owl` as an OWL axiom (proper solution)
