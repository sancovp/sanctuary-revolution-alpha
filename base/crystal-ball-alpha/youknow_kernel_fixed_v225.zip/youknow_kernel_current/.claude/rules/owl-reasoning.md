# OWL Reasoning - CRITICAL ISSUE

**UNTYPED PRIMITIVES WITHOUT AXIOMATIC DEFINITIONS ARE NOT AN ONTOLOGY.**

## The Problem

The relationships (`is_a`, `part_of`, `instantiates`) currently have:
- No domain/range constraints in OWL
- No property chains for inference
- No reasoner running to exploit `owl:TransitiveProperty` declarations
- Python string matching instead of logical entailment

**SHACL IS NOT REASONING.** It only checks "does this property exist?" - not "what can we infer?"

## What Must Be Fixed

1. **Add domain/range axioms** to core primitives in `uarl_v3.owl`

2. **Add property chains** for inference rules:
   ```
   SubObjectPropertyOf(
     ObjectPropertyChain(:partOf :isA)
     :isA
   )
   ```

3. **Wire a real reasoner** - Pellet, HermiT, or ELK must run on the OWL

4. **Y-layer constraints in OWL** - Not just Python dicts

5. **Guard on instantiates** - X cannot instantiate something higher in Reality than itself (needs OWL axiom)

## The Test

If you can't load the OWL into Protégé and run a reasoner that derives NEW facts, it's not an ontology - it's just XML documentation.
