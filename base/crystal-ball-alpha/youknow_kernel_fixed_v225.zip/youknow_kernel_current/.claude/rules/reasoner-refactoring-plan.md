# OWL Reasoner Refactoring Plan

## Current State (BROKEN)

- SHACL validates structure only ("does property exist?")
- Python walks dicts manually for chain tracing
- OWL axioms exist but NO REASONER runs
- `owl:TransitiveProperty` declarations are unused
- **Result: "Ontology cosplay" - just verbose XML documentation**

## Goal State

- Real OWL2 reasoner (Pellet via owlready2)
- Axioms do the work, not explicit Python checks
- Inference derives new facts automatically
- Derivation chain validated via reasoning, not string matching

---

## Phase 1: Reasoner Integration (Minimal Change)

**Create `owl_reasoner.py`:**
```python
class OWLReasoner:
    def __init__(self, foundation_owl_path, domain_owl_path=None):
        # Load foundation OWL (frozen)
        # Load domain OWL (user assertions)
        # Initialize Pellet backend via owlready2

    def add_assertion(self, subject, predicate, object_):
        # Add triple to domain ontology

    def run_inference(self):
        # sync_reasoner() - compute entailments

    def query(self, sparql_or_api):
        # Query inferred model

    def validate_derivation(self, concept_uri) -> DerivationState:
        # Query: does is_a chain reach Cat_of_Cat?
        # Query: does part_of chain have grounded root?
        # Return derivation state with proof
```

**Dependencies:**
- `owlready2` (pip install owlready2)
- Java runtime (for Pellet)
- Pellet JAR (owlready2 can download automatically)

---

## Phase 2: Replace SHACL with Reasoner Queries

**Current (uarl_validator.py):**
```python
def validate_concept(concept_data, domain_owl_path):
    result = pyshacl.validate(...)  # Structural check
    return SHACLValidationResult(...)
```

**New:**
```python
def validate_concept(concept_data, reasoner: OWLReasoner):
    reasoner.add_assertion(concept_data)
    reasoner.run_inference()

    # Query inferred facts instead of checking shapes
    is_valid = reasoner.query("ASK { ?x a uarl:Reality }")
    derivation = reasoner.validate_derivation(concept_uri)

    return ReasonerValidationResult(derivation)
```

---

## Phase 3: Derivation Chain via Reasoning

**Add OWL rules/axioms for the L0-L6 chain:**

```turtle
# Transitive closure (already declared, now USED)
:isA a owl:TransitiveProperty .
:partOf a owl:TransitiveProperty .

# Derivation rules (SWRL or OWL2 RL)
# L3→L4: reifies enables is_a_promotion
# L4→L5: is_a_promotion enables instantiates
# L5→L6: instantiates pattern_of_is_a enables programs

# Reality membership
:PatternOfIsA a owl:Class .
[ a owl:Restriction ;
  owl:onProperty :instantiates ;
  owl:someValuesFrom :PatternOfIsA
] rdfs:subClassOf :Reality .
```

**Reasoner query for "chain closes":**
```sparql
ASK {
    ?concept :isA+ :Cat_of_Cat .
    ?concept :partOf+ ?root .
    ?root a :Reality .
}
```

---

## Phase 4: Compiler Integration

**compiler.py changes:**
```python
def youknow(statement: str) -> str:
    parsed = parse_statement(statement)

    # Add to domain OWL
    reasoner.add_assertion(parsed.subject, parsed.predicate, parsed.object)

    # Run inference
    reasoner.run_inference()

    # Query spiral
    derivation = reasoner.validate_derivation(parsed.subject)

    if derivation.reaches_cat_of_cat:
        return "OK"
    else:
        return f"Wrong because: {derivation.whats_missing}"
```

---

## Phase 5: Performance Tuning

| Issue | Solution |
|-------|----------|
| Pellet startup (~500ms) | Persistent reasoner process |
| Memory (~50-200MB) | Cache foundation OWL |
| Repeated inference | Batch assertions, incremental reasoning |
| Java dependency | Document, or fallback to owlrl (limited) |

---

## OWL Axioms to Add (uarl_v3.owl)

1. **Property chains** for inference:
   ```
   SubObjectPropertyOf(
     ObjectPropertyChain(:partOf :isA)
     :isA
   )
   ```

2. **Domain/range** on core primitives

3. **Disjointness**: Reality ⊥ Hallucination

4. **MSC relationship** (replacing generative "instantiates"):
   ```turtle
   :msc a owl:ObjectProperty ;
       rdfs:label "most specific consequence" ;
       rdfs:comment "X msc Y = Y is the most specific thing entailed by X" .
   ```

5. **Y-layer guard** as OWL axiom (X cannot msc something higher than itself)

---

## Terminology Cleanup

| Current | Issue | New |
|---------|-------|-----|
| `instantiates` (generative) | Collides with rdf:type | `msc` (most specific consequence) |
| `instantiates` (standard) | Keep for rdf:type | Keep |
| `reifies` (as step) | Should be result | Clarify: reification = result of valid instantiation |

---

## Files to Change

1. **NEW**: `youknow_kernel/owl_reasoner.py` - Reasoner wrapper
2. **MODIFY**: `youknow_kernel/uarl_validator.py` - Replace pyshacl → reasoner
3. **MODIFY**: `youknow_kernel/compiler.py` - Wire reasoner
4. **MODIFY**: `youknow_kernel/uarl_v3.owl` - Add axioms
5. **MODIFY**: `youknow_kernel/cat_of_cat.py` - Use reasoner queries instead of dict traversal

---

## Success Criteria

1. `youknow("Dog is_a Animal")` returns OK/Wrong based on REASONER inference
2. Transitive is_a chain computed by reasoner, not Python
3. New assertions checked for consistency with existing ontology
4. Derivation chain (L0-L6) validated via reasoning queries
5. No more SHACL - all validation via OWL entailment
