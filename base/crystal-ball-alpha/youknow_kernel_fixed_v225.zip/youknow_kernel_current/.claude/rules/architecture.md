# YOUKNOW Architecture Rules

## The Entry Point

**THE entry point is `youknow(statement)` in `compiler.py`.**

Everything goes through the compiler. Never call `cat.add()` or `mi.yk.add()` directly for validation. Those are internal.

## Current State vs Goal State

### CURRENT (broken):
- OWL file exists but NO REASONER running
- SHACL does structural validation only ("does property exist?")
- Python does ALL "reasoning" via dict traversal
- Relationships are strings with no semantics

### GOAL:
- OWL axioms with domain/range constraints
- Property chains for inference (X part_of Y, Y is_a Z → infer X is_a Z)
- Actual reasoner (Pellet/HermiT/ELK) running inference
- Derived facts from logical entailment

## The Derivation Chain

L0 → L1 → L2 → L3 → L4 → L5 → L6 (CODEGEN)

Each level adds structure. Chain must reach Cat_of_Cat for "OK".
Chain breaks = "Wrong because: X is_a ? (unknown)"

## Key Files

| File | Purpose |
|------|---------|
| `compiler.py` | THE entry point - `youknow()` |
| `hyperedge.py` | HyperedgeValidator for EMR |
| `derivation.py` | DerivationValidator for L0-L6 |
| `cat_of_cat.py` | Chain tracing to root |
| `uarl_v3.owl` | Foundation ontology (needs reasoner!) |
| `uarl_shapes.ttl` | SHACL shapes (structural only) |
