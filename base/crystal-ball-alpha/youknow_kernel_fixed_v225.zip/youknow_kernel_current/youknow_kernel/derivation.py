"""
YOUKNOW Derivation Validator

This is NOT string matching. This validates the DERIVATION CHAIN.

The pattern_of_is_a is achieved when a concept has:
1. Traced through embodies → manifests → reifies → instantiates → programs
2. Each step has its requirements satisfied
3. The final state is isA_pattern (Reality)

Three types of is_a:
- isA_primitive: Raw assertion (SOUP level)
- isA_promotion: Gone through EMR (becomes generative)
- isA_pattern: Matches pattern_of_is_a (is Reality)

Seven derivation steps (Core Sentence):
1. is_a_primitive (L0: String Soup)
2. embodies (L1: Named Slots) - self-identification
3. manifests (L2: Typed Slots) - containment 
4. reifies (L3: Struct Types) - pattern locked
5. is_a_promotion (L4+: Recursive) - becomes Program
6. instantiates (Closure) - produces part_of Reality
7. programs (LITERAL CODEGEN) - Cat-of-Cat witness
"""

from typing import Dict, List, Optional, Any, Set
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime


class DerivationLevel(Enum):
    """The 7 levels of the derivation chain."""
    L0_STRING_SOUP = 0      # Raw is_a_primitive
    L1_NAMED_SLOTS = 1      # embodies
    L2_TYPED_SLOTS = 2      # manifests
    L3_STRUCT_TYPES = 3     # reifies
    L4_RECURSIVE = 4        # is_a_promotion
    L5_CLOSURE = 5          # instantiates
    L6_CODEGEN = 6          # programs (Reality)


class IsAType(Enum):
    """Three aspects of is_a."""
    PRIMITIVE = "isA_primitive"     # Raw assertion (SOUP)
    PROMOTION = "isA_promotion"     # Gone through EMR
    PATTERN = "isA_pattern"         # Matches pattern_of_is_a (Reality)


@dataclass
class DerivationState:
    """The derivation state of a concept."""
    name: str
    level: DerivationLevel = DerivationLevel.L0_STRING_SOUP
    is_a_type: IsAType = IsAType.PRIMITIVE
    
    # State flags
    has_is_a_primitive: bool = False    # L0
    has_embodies: bool = False          # L1: has stable slots
    has_manifests: bool = False         # L2: slots are typed
    has_reifies: bool = False           # L3: types have structure
    has_is_a_promotion: bool = False    # L4: promoted to Program
    has_instantiates: bool = False      # L5: produces instances
    has_programs: bool = False          # L6: Cat-of-Cat witness
    
    # Typed depth (how many layers are typed before soup)
    typed_depth: int = 0
    
    # What's missing for next level
    whats_missing: List[str] = field(default_factory=list)
    
    def is_soup(self) -> bool:
        """Is this still in SOUP (unvalidated)?"""
        return self.level.value < DerivationLevel.L3_STRUCT_TYPES.value
    
    def is_ont(self) -> bool:
        """Is this in ONT (validated)?"""
        return self.level.value >= DerivationLevel.L5_CLOSURE.value
    
    def is_reality(self) -> bool:
        """Has this reached Reality (Cat-of-Cat witness)?"""
        return self.has_programs


@dataclass 
class DerivationRequirements:
    """What a concept needs for each derivation level."""
    
    @staticmethod
    def for_embodies(concept: Dict) -> List[str]:
        """L1: What's needed for embodies (named slots)?"""
        missing = []
        if not concept.get("name"):
            missing.append("name: stable identifier")
        if not concept.get("is_a"):
            missing.append("is_a: at least one parent")
        if not concept.get("description"):
            missing.append("description: what it is")
        return missing
    
    @staticmethod
    def for_manifests(concept: Dict) -> List[str]:
        """L2: What's needed for manifests (typed slots)?"""
        missing = []

        # Real typing comes from is_a/part_of relationships and tracing to Cat_of_Cat
        # Not from XML Schema prefixes - removed xsd: check as over-engineering

        if not concept.get("y_layer"):
            missing.append("y_layer: which Y-strata layer")
        return missing
    
    @staticmethod
    def for_reifies(concept: Dict) -> List[str]:
        """L3: What's needed for reifies (structured types)?"""
        missing = []
        # is_a targets must themselves be typed
        is_a = concept.get("is_a", [])
        for parent in is_a:
            # In real use, we'd check if parent has typed depth >= 1
            pass  # Placeholder
        if not concept.get("part_of"):
            missing.append("part_of: where it belongs in the structure")
        return missing
    
    @staticmethod
    def for_promotion(concept: Dict, cat) -> List[str]:
        """L4: What's needed for is_a_promotion (recursive)?"""
        missing = []
        # Must trace to Cat_of_Cat
        name = concept.get("name", "")
        if cat and not cat.validate_traces_to_root(name):
            parents = concept.get("is_a", [])
            has_prospective_root = any(
                parent in getattr(cat, "entities", {}) and cat.validate_traces_to_root(parent)
                for parent in parents
            )
            if not has_prospective_root:
                missing.append("Doesn't trace to Cat_of_Cat")
        return missing
    
    @staticmethod
    def for_instantiates(concept: Dict) -> List[str]:
        """L5: What's needed for instantiates (closure)?"""
        missing = []
        if not concept.get("instantiates"):
            missing.append("instantiates: what it produces")
        return missing
    
    @staticmethod
    def for_programs(concept: Dict) -> List[str]:
        """L6: What's needed for programs (codegen)?"""
        missing = []
        # Must have python_class or template (check top-level AND properties)
        props = concept.get("properties", {})
        has_python_class = concept.get("python_class") or props.get("python_class")
        has_template = concept.get("template") or props.get("template")
        if not has_python_class and not has_template:
            missing.append("python_class or template: code realization")
        return missing


class DerivationValidator:
    """
    Validates derivation chains properly.
    
    NOT string matching. Checks actual requirements at each level.
    """
    
    def __init__(self, cat=None):
        """
        Args:
            cat: CategoryOfCategories instance (for Cat_of_Cat checks)
        """
        self.cat = cat
    
    def validate(self, concept: Dict[str, Any]) -> DerivationState:
        """
        Validate a concept's derivation state.
        
        Returns DerivationState showing:
        - Current level (L0-L6)
        - is_a type (primitive/promotion/pattern)
        - What's missing for next level
        """
        name = concept.get("name", "unknown")
        state = DerivationState(name=name)
        
        # Check each level progressively
        
        # L0: is_a_primitive (has any is_a at all)
        if concept.get("is_a"):
            state.has_is_a_primitive = True
            state.level = DerivationLevel.L0_STRING_SOUP
        
        # L1: embodies (has named slots)
        missing_l1 = DerivationRequirements.for_embodies(concept)
        if not missing_l1:
            state.has_embodies = True
            state.level = DerivationLevel.L1_NAMED_SLOTS
            state.typed_depth = 1
        else:
            state.whats_missing = missing_l1
            return state
        
        # L2: manifests (slots are typed)
        missing_l2 = DerivationRequirements.for_manifests(concept)
        if not missing_l2:
            state.has_manifests = True
            state.level = DerivationLevel.L2_TYPED_SLOTS
            state.typed_depth = 2
        else:
            state.whats_missing = missing_l2
            return state
        
        # L3: reifies (types have structure)
        missing_l3 = DerivationRequirements.for_reifies(concept)
        if not missing_l3:
            state.has_reifies = True
            state.level = DerivationLevel.L3_STRUCT_TYPES
            state.typed_depth = 3
            state.is_a_type = IsAType.PROMOTION  # Now it's promoted
        else:
            state.whats_missing = missing_l3
            return state
        
        # L4: is_a_promotion (recursive, traces to Cat_of_Cat)
        missing_l4 = DerivationRequirements.for_promotion(concept, self.cat)
        if not missing_l4:
            state.has_is_a_promotion = True
            state.level = DerivationLevel.L4_RECURSIVE
            state.typed_depth = 4
        else:
            state.whats_missing = missing_l4
            return state
        
        # L5: instantiates (closure)
        missing_l5 = DerivationRequirements.for_instantiates(concept)
        if not missing_l5:
            state.has_instantiates = True
            state.level = DerivationLevel.L5_CLOSURE
            state.typed_depth = 5
        else:
            state.whats_missing = missing_l5
            return state
        
        # L6: programs (Cat-of-Cat witness, codegen)
        missing_l6 = DerivationRequirements.for_programs(concept)
        if not missing_l6:
            state.has_programs = True
            state.level = DerivationLevel.L6_CODEGEN
            state.typed_depth = 6
            state.is_a_type = IsAType.PATTERN  # Now it's Reality
        else:
            state.whats_missing = missing_l6
            return state
        
        return state
    
    def validate_for_promotion(self, concept: Dict[str, Any], min_depth: int = 3) -> Dict[str, Any]:
        """
        Check if concept is ready for SOUP → ONT promotion.
        
        Requirements (from UARL v4):
        1. typed_depth >= minimum_typed_layers
        2. no_untyped_morphisms
        3. llm_satisfied (we assume True if other checks pass)
        """
        state = self.validate(concept)
        
        can_promote = state.typed_depth >= min_depth
        
        return {
            "can_promote": can_promote,
            "state": state,
            "typed_depth": state.typed_depth,
            "required_depth": min_depth,
            "whats_missing": state.whats_missing,
            "is_ont": state.is_ont(),
            "is_reality": state.is_reality(),
        }


# =============================================================================
# DEMO
# =============================================================================

if __name__ == "__main__":
    print("=== DERIVATION VALIDATOR ===")
    print()
    
    validator = DerivationValidator()
    
    # Test concept at L0 (soup)
    soup_concept = {
        "name": "RawThing",
        "is_a": ["Something"],
    }
    state = validator.validate(soup_concept)
    print("1. Soup concept (minimal):")
    print(f"   Level: {state.level.name}")
    print(f"   is_a type: {state.is_a_type.value}")
    print(f"   Typed depth: {state.typed_depth}")
    print(f"   Missing: {state.whats_missing}")
    print()
    
    # Test concept at L3 (reified)
    typed_concept = {
        "name": "SkillSpec",
        "is_a": ["Category"],
        "description": "Specification for a PAIA skill",
        "y_layer": "Y3",
        "part_of": ["PAIAB_System"],
        "properties": {
            "domain": "xsd:string",
            "category": "xsd:string",
        }
    }
    state = validator.validate(typed_concept)
    print("2. Typed concept (L3):")
    print(f"   Level: {state.level.name}")
    print(f"   is_a type: {state.is_a_type.value}")
    print(f"   Typed depth: {state.typed_depth}")
    print(f"   Missing: {state.whats_missing}")
    print()
    
    # Test concept at L6 (Reality)
    reality_concept = {
        "name": "SkillSpec",
        "is_a": ["Category"],
        "description": "Specification for a PAIA skill",
        "y_layer": "Y3",
        "part_of": ["PAIAB_System"],
        "instantiates": ["SkillPackage"],
        "python_class": "SkillSpec",
        "properties": {
            "domain": "xsd:string",
            "category": "xsd:string",
        }
    }
    state = validator.validate(reality_concept)
    print("3. Reality concept (L6):")
    print(f"   Level: {state.level.name}")
    print(f"   is_a type: {state.is_a_type.value}")
    print(f"   Typed depth: {state.typed_depth}")
    print(f"   Is SOUP: {state.is_soup()}")
    print(f"   Is ONT: {state.is_ont()}")
    print(f"   Is Reality: {state.is_reality()}")
    print()
    
    # Test promotion check
    print("4. Promotion check (min_depth=3):")
    result = validator.validate_for_promotion(typed_concept, min_depth=3)
    print(f"   Can promote: {result['can_promote']}")
    print(f"   Typed depth: {result['typed_depth']}")
    print(f"   Missing: {result['whats_missing']}")
